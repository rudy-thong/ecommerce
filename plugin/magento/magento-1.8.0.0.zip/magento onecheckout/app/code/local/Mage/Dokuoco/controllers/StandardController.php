<?php

class Mage_Dokuoco_StandardController extends Mage_Core_Controller_Front_Action
{
    /**
     * Order instance
     */
    protected $_order;
    
    /**
     *  Get order
     *
     *  @param    none
     *  @return	  Mage_Sales_Model_Order
     */
    public function getOrder()
    {
        if ($this->_order == null) {
        }
        return $this->_order;
    }

    protected function _expireAjax()
    {
        if (!Mage::getSingleton('checkout/session')->getQuote()->hasItems()) {
            $this->getResponse()->setHeader('HTTP/1.1','403 Session Expired');
            exit;
        }
    }

    /**
     * Get singleton with Doku Standard order transaction information
     *
     * @return Mage_Doku_Model_Standard
     */
    public function getStandard()
    {
        return Mage::getSingleton('Dokuoco/standard');
    }

    /**
     * When a customer chooses Doku on Checkout/Payment page
     *
     */
    public function redirectAction()
    {
    
        $session = Mage::getSingleton('checkout/session');
        $session->setDokuocoStandardQuoteId($session->getQuoteId());
        $session->unsQuoteId();
		
       $lastQuoteId = $session->getLastQuoteId();
        $lastOrderId = $session->getLastOrderId();
		
		       
        
        $this->loadLayout();
        $this->getLayout()->getBlock('content')->append($this->getLayout()->createBlock('Dokuoco/standard_redirect'));
        $this->renderLayout();

    }
	
	
	/* aktifkan blok ini jika script utk menambahkan mobile dan workphone
	pada mysql_setup dari modul ini tidak berjalan */
	
	
/*	public function runqueryAction()
    {
    
        $session = Mage::getSingleton('checkout/session');
        $session->setDokuocoStandardQuoteId($session->getQuoteId());
        $session->unsQuoteId();
		
	
	
	//Attribute to add
$newAttributeName = "mobilephone"; //modify this with the name of your attribute
 
//a) Add EAV Attributes (modify as you needed)
$attribute  = array(
    'type'          => 'varchar',
    'label'         => 'Mobile Phone',
    'visible'       => 1,
    'required'      => 0,
    'user_defined'  => 0,
    'searchable'    => 0,
    'filterable'    => 0,
    'comparable'    => 0,
);
 
$setup = new Mage_Eav_Model_Entity_Setup('core_setup');
//Add to customer
$setup->addAttribute('customer', $newAttributeName, $attribute);
 
//b) Add Quote attributes (one page step to step save field)
$setup = new Mage_Sales_Model_Mysql4_Setup('sales_setup');
$setup->getConnection()->addColumn(
        $setup->getTable('sales_flat_quote'),
        $newAttributeName,
        'text NULL DEFAULT NULL'
    );
$setup->addAttribute('quote', "customer_".$newAttributeName, array('type' => 'static', 'visible' => 0));

//========set workphone =======================
$newAttributeName2 = "workphone"; //modify this with the name of your attribute
 
//a) Add EAV Attributes (modify as you needed)
$attribute2  = array(
    'type'          => 'varchar',
    'label'         => 'Work Phone',
    'visible'       => 1,
    'required'      => 0,
    'user_defined'  => 0,
    'searchable'    => 0,
    'filterable'    => 0,
    'comparable'    => 0,
);
 
$setup2 = new Mage_Eav_Model_Entity_Setup('core_setup');
//Add to customer
$setup2->addAttribute('customer', $newAttributeName2, $attribute2);
 
//b) Add Quote attributes (one page step to step save field)
$setup2 = new Mage_Sales_Model_Mysql4_Setup('sales_setup');
$setup2->getConnection()->addColumn(
        $setup2->getTable('sales_flat_quote'),
        $newAttributeName2,
        'text NULL DEFAULT NULL'
    );
$setup2->addAttribute('quote', "customer_".$newAttributeName2, array('type' => 'static', 'visible' => 0));



	
	
		       
		
    }*/

    /**
     * When a customer cancel payment from Doku.
     */
    public function cancelAction()
    {
        $session = Mage::getSingleton('checkout/session');

        // cancel order
        if ($session->getLastOrderId()) {
			
           // $order = Mage::getModel('sales/order')->loadByIncrementId($session->getLastRealOrderId());
		   $order = Mage::getModel('sales/order')->load($session->getLastOrderId());
            if ($order->getId()) {
               // $order->cancel()->save();
			   				
			   				$order->setState(Mage_Sales_Model_Order::STATE_CANCELED, true);
							$order->addStatusHistoryComment("Payment has beed cancelled on Doku Page");
							$order->sendNewOrderEmail();
							$order->setEmailSent(true);
							$order->save();
            }
        }

        $this->_redirect('checkout/cart');
    }



		/**
		 * when Doku verify
		 */
		public function verifyAction()
		{
			// selama tahap development, kondisi ini boleh tidak digunakan
			//if ($_SERVER['REMOTE_ADDR'] != '202.182.62.118'){
				//header("location:index.php");
			//}
				if ($_GET['TRANSIDMERCHANT']) {
					$order_number = $_GET['TRANSIDMERCHANT'];
					$purchase_amt = $_GET['AMOUNT'];
				} else {
					$order_number = 0;
					$purchase_amt = 0;
				}
				//load order from magento using transidmerchant
					$order = Mage::getModel('sales/order')->load($order_number);
				
				
				$purchase_currency = $_GET['CURRENCY'];
				$sql = "select nsia_id ,amount from dokuoco where nsia_order_id=$order_number and amount=$purchase_amt and status='Requested' order by nsia_id desc limit 1";
			
				$checkout = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchRow($sql);
			
				$hasil=$checkout['nsia_id'];
				
				if (!$hasil) {
						
							/*$order->setState(Mage_Sales_Model_Order::STATE_CANCELED, true);
							$order->addStatusHistoryComment("Fail on verify");
							$order->sendNewOrderEmail();
							$order->setEmailSent(true);
							$order->save();*/
							$order->setState("dokufailed", true);
								$order->addStatusHistoryComment("Failed on verify Payment");
								//$order->sendNewOrderEmail();
								//$order->setEmailSent(true);
								$order->save();
				
				  echo 'Stop';
			
				} else {
			
					$sql = "UPDATE dokuoco set status='Verified' where nsia_id=$hasil";
					$result = Mage::getSingleton('core/resource')->getConnection('core_write')->query($sql);
			
					$sql = "select status from dokuoco where nsia_id=$hasil";
					$result = Mage::getSingleton('core/resource') ->getConnection('core_read')->fetchRow($sql);
			
					if ($result['status']=="Verified"){
							
							$order->setState(Mage_Sales_Model_Order::STATE_PROCESSING, true);
							$order->addStatusHistoryComment("Processing Payment");
							//$order->sendNewOrderEmail();
							//$order->setEmailSent(true);
							$order->save();
						echo 'Continue';
					} else {
							
							/*$order->setState(Mage_Sales_Model_Order::STATE_CANCELED, true);
							$order->addStatusHistoryComment("Fail on verify");
							$order->sendNewOrderEmail();
							$order->setEmailSent(true);
							$order->save();*/
						
								
								$order->setState("dokufailed", true);
								$order->addStatusHistoryComment("Failed on verify Payment");
								//$order->sendNewOrderEmail();
								//$order->setEmailSent(true);
								$order->save();
						echo 'Stop';
					}
				}
		}

		/**
		 * when Doku notify
		 */
		public function notifyAction()
		{
			// selama tahap development, kondisi ini boleh tidak digunakan
			//if ($_SERVER['REMOTE_ADDR'] != '202.182.62.118'){
				//header("location:index.php");
			//}
			
			//tambahkan pembaca response code
			/*$lastQuoteId = $session->getLastQuoteId();
        $lastOrderId = $session->getLastOrderId();
		
							$order = Mage::getModel('sales/order')->load($lastOrderId);
							$order->addStatusHistoryComment("Declined Payment");
							$order->setState("dokudeclined", true);
							$order->sendNewOrderEmail();
							$order->setEmailSent(true);
							$order->save();*/
			
			if ($_POST['TRANSIDMERCHANT']) {
				$order_number = $_POST['TRANSIDMERCHANT'];
				$status = $_POST['RESULTMSG'];
				$respcode = $_POST['RESPONSECODE'];
				$statustype = $_POST['STATUSTYPE'];
				$amounttrans = $_POST['AMOUNT'];
				$words = $_POST['WORDS'];
				$approvalcode = $_POST['APPROVALCODE'];
				$paymentchannel = $_POST['PAYMENTCHANNEL'];
				$sessionid = $_POST['SESSIONID'];
				$bank = $_POST['BANK'];
				$mcn = $_POST['MCN'];
				
				
				$paymentdatetime = $_POST['PAYMENTDATETIME'];
				$payday = date('Y-m-d h:m:s', $getTgl);
				
				
				
				$verifyid = $_POST['VERIFYID'];
				$verifyscore = $_POST['VERIFYSCORE'];
				$verifystatus = $_POST['VERIFYSTATUS'];
				
				
			} else { 
				$order_number = 0;
				$status = "";
			}
				
				//$msg = $_GET['RESULGMSG'];
			
			
			// Basic SQL
			
				$sql = "select nsia_id,amount from dokuoco where nsia_order_id=$order_number and status='Requested' order by nsia_id desc limit 1";
				//echo $sql."<br>";
			
				$checkout = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchRow($sql);
				$hasil=$checkout['nsia_id'];
				$amount=$checkout['amount'];
				//echo "hasil=".$hasil;
				
			// Custom Field
			
				if (!$hasil) {
			
				  echo 'Stop';
				 
				 
			
				} else {
			
					if ($status=="SUCCESS")
					{
			
					  $sql = 	"UPDATE dokuoco set status='SUCCESS',finish_time='$payday', ".
					  			"statustype='$statustype' , response_code='$respcode' , approval_code='$approvalcode',".
								"result_message='$status' , payment_channel='$paymentchannel' , bank='$bank' ,".
								"mcn='$mcn' , verify_id='$verifyid', verify_score=$verifyscore , verify_status='$verifystatus' ".
					  			"where nsia_id=$hasil";
			
						$result = Mage::getSingleton('core/resource')->getConnection('core_write')->query($sql);
			
						$sql = "select status from dokuoco where nsia_id=$hasil";
						$result = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchRow($sql);
						//echo "sql=".$sql;
						if($result['status']!="SUCCESS")
							{
								echo "Stop";
								die();
							} else {
								
								//$order = Mage::getModel('sales/order')->loadByIncrementId($order_number);
								$order = Mage::getModel('sales/order')->load($order_number);
								
								
								//$order->setState(Mage_Sales_Model_Order::STATE_COMPLETE, true);
								$order->addStatusToHistory(Mage_Sales_Model_Order::STATE_COMPLETE);
								$order->addStatusHistoryComment('Payment Successful');
								//$order->setState(Mage_Sales_Model_Order::STATE_COMPLETE, false);
								$order->sendNewOrderEmail();
								$order->setEmailSent(true);
								$order->save(); 
	
							}
			
					} else {
			 
			 		 // $sql = "UPDATE dokuoco set status='Fail' where nsia_id=$hasil";
					  $sql = 	"UPDATE dokuoco set status='FAILED',finish_time='$payday', ".
					  			"statustype='$statustype' , response_code='$respcode' , approval_code='$approvalcode',".
								"result_message='$status' , payment_channel='$paymentchannel' , bank='$bank' ,".
								"mcn='$mcn' , verify_id='$verifyid', verify_score=$verifyscore , verify_status='$verifystatus' ".
					  			"where nsia_id=$hasil";
					  
						$result = Mage::getSingleton('core/resource')->getConnection('core_write')->query($sql);
			
						$sql = "select status from dokuoco where nsia_id=$hasil";
						
						$result = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchRow($sql);
					
						if($result['status']!="Fail")
							{
								echo "Stop";
								die();
							} else {
								//$order = Mage::getModel('sales/order')->loadByIncrementId($order_number);
								$order = Mage::getModel('sales/order')->load($order_number);
								$order->addStatusHistoryComment("Payment Fail. Error Code : ".$respcode);
								$order->setStatus(Mage_Sales_Model_Order::STATE_CANCELED); 
								//$order->addStatusToHistory('Payment Failed', '', true);
								$order->sendNewOrderEmail();
								$order->setEmailSent(true);
								$order->save(); 
								// set order status and state to declined
								/*$order = Mage::getModel('sales/order')->load($order_number);
								
								$order->setState("dokudeclined", true);
								$order->addStatusHistoryComment("Declined Payment. Error Code : ".$respcode);
								$order->sendNewOrderEmail();
								$order->setEmailSent(true);
								$order->save();*/
							}
					}
			
					echo 'Continue';
					
				}
		}
		
    /**
     * when Doku returns
     */

    public function processAction()
    {    	    
        if($_POST)
		{
			
            if (isset($_POST['TRANSIDMERCHANT']))
			{

                $TRANSIDMERCHANT = $_POST['TRANSIDMERCHANT'];
				$order = Mage::getModel('sales/order')->load($TRANSIDMERCHANT);
            	$session = Mage::getSingleton('checkout/session');
				
                //if ($session->getLastRealOrderId()) {

                    //$order = Mage::getModel('sales/order')->loadByIncrementId($TRANSIDMERCHANT);
                    if ($order->getId())
						{
							
							if($this->dokuocoSuccess())
								{
	
									$session->setOrderId($TRANSIDMERCHANT);
									
									$session->setQuoteId($session->getDokuocoStandardQuoteId());
									
		
									 $this->loadLayout();
        $this->getLayout()->getBlock('content')->append($this->getLayout()->createBlock('Dokuoco/standard_success'));
        $this->renderLayout();

									
	
								}else{
								
								//Mage::getSingleton('core/session')->addError('There was a problem completing your order. Please try again');
								//$session->addError('There was a problem completing your order. Please try again');
								
								/*$order->cancel();
								
								$order->save();*/
								$this->getResponse()->setBody($this->getLayout()->createBlock('Dokuoco/standard_error')->toHtml());
								
								}
                   		 } else {
							 
								$order->addStatusToHistory('No Invoice', '', true);
								$order->save();
						}
                	//} else {
					//$order->addStatusToHistory('No Invoice', '', false);
                	//$order->save();
					//}
					
            } 
			
			
        }else{
                //set the quote as inactive after back from Doku
            $session->getQuote()->setIsActive(false)->save();

            $this->_redirect('checkout/onepage/failure', array('_secure'=>true));
        }
      
    }
    
    public function dokuocoSuccess(){
        $TRANSIDMERCHANT = $_POST['TRANSIDMERCHANT'];
        $STATUSCODE = $_POST['STATUSCODE'];
        $AMOUNT = $_POST['AMOUNT'];

		$sql = "select nsia_id,amount from dokuoco where nsia_order_id=$TRANSIDMERCHANT and (status='SUCCESS' or status='FAILED') and amount=$AMOUNT order by nsia_id desc limit 1";
		
        $proc = Mage::getSingleton('core/resource')->getConnection('core_read')->fetchRow($sql);
				
        if ($proc['nsia_id']){
            if ($STATUSCODE == "0000") {
					
					foreach( Mage::getSingleton('checkout/session')->getQuote()->getItemsCollection() as $item )
					{
						
    					Mage::getSingleton('checkout/cart')->removeItem( $item->getId() )->save();
					}
				return true;
            }else{
				
				/*Mage::getSingleton('core/session')->addError('There was a problem completing your order. Please try again');
				//$session->addError('There was a problem completing your order. Please try again');
				
				$order->cancel();
				
				$order->save();
				*/
				return false;
	    	}
   	    } else {
            return false;
		}
		
    }
    
    protected function _createInvoice($orderIncrementId){
    
        $order = Mage::getModel('sales/order')->loadByIncrementId($orderIncrementId);

        $itemsQty = count($order->getAllItems());

        $invoice = $order->prepareInvoice($itemsQty);

        $invoice->register();
        
        $invoice->setOrder($order);

        $invoice->setEmailSent(true);
    
        $invoice->getOrder()->setIsInProcess(true);

        $invoice->pay();
        
        $invoice->save();
        
        $order->save();

        return $invoice->getIncrementId();
    
    }
	
    
    public function failureAction(){
		$session = Mage::getSingleton('checkout/session');
        $lastQuoteId = $session->getLastQuoteId();
        $lastOrderId = $session->getLastOrderId();

        if (!$lastQuoteId || !$lastOrderId) {
            $this->_redirect('checkout/cart');
            return;
        }
        
        $order = Mage::getModel('sales/order')->loadByAttribute('entity_id', $lastOrderId);

       	if ($order->getId()) {
        	$order->cancel()->save();
	    }
        
        $this->_redirect('checkout/onepage/failure');
        return;

    }
}
