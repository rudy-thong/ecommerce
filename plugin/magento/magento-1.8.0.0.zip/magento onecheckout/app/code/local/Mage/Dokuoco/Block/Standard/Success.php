<?php

class Mage_Dokuoco_Block_Standard_Success extends Mage_Core_Block_Abstract
{
    protected function _toHtml()
    {
    	$html = '<html><head></head><body>';
	    
	    $html .= '<form action="' . Mage::getUrl('checkout/onepage/success') . '" id="Dokuoco_standard_response" method="POST"></form>';
			$html .= '<script type="text/javascript">document.getElementById("Dokuoco_standard_response").submit();</script>';

	    $html .= '</body></html>';
	           	 
    	return $html;
    }
}

?>