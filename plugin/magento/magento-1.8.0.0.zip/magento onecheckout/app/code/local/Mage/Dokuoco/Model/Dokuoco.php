<?php 

class Mage_Dokuoco_Model_Dokuoco extends Mage_Core_Model_Abstract
{
    protected function _construct()
    {
        $this->_init('dokuoco/dokuoco');
    }	
}