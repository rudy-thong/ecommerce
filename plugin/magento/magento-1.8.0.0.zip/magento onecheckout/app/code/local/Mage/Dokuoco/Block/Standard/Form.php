<?php

class Mage_Dokuoco_Block_Standard_Form extends Mage_Payment_Block_Form
{
    protected function _construct()
    {
        $this->setTemplate('Dokuoco/standard/form.phtml');
        parent::_construct();
    }
}