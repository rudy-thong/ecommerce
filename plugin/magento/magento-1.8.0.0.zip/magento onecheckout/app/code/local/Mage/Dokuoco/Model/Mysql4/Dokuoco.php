<?php 

class Mage_Dokuoco_Model_Mysql4_Dokuoco extends Mage_Core_Model_Mysql4_Abstract
{
    protected function _construct()
    {
        $this->_init('dokuoco/dokuoco', 'dokuoco_id');
    }	
}