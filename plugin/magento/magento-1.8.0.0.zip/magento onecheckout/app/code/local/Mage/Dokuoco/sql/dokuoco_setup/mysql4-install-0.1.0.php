<?php

$installer = $this;





$installer->startSetup();

//================add new customer attribute====================
$this->addAttribute('customer_address', 'mobilephone', array(
    'type' => 'varchar',
    'input' => 'text',
    'label' => 'Mobile Phone#',
    'global' => 1,
    'visible' => 1,
    'required' => 1,
    'user_defined' => 1,
    'visible_on_front' => 1
));
Mage::getSingleton('eav/config')
    ->getAttribute('customer_address', 'mobilephone')
    ->setData('used_in_forms', array('customer_register_address','customer_address_edit','adminhtml_customer_address'))
    ->save();
	
$this->addAttribute('customer_address', 'workphone', array(
    'type' => 'varchar',
    'input' => 'text',
    'label' => 'Work Phone#',
    'global' => 1,
    'visible' => 1,
    'required' => 0,
    'user_defined' => 1,
    'visible_on_front' => 1
));
Mage::getSingleton('eav/config')
    ->getAttribute('customer_address', 'workphone')
    ->setData('used_in_forms', array('customer_register_address','customer_address_edit','adminhtml_customer_address'))
    ->save();
	
	

//==============================================================

$tablequote = $this->getTable('sales/quote_address');
$installer->run("
ALTER TABLE  $tablequote ADD  `mobilephone` varchar(255) NOT NULL
");
 
$tablequote = $this->getTable('sales/order_address');
$installer->run("
ALTER TABLE  $tablequote ADD  `mobilephone` varchar(255) NOT NULL
");
//=============================================================
$tablequote = $this->getTable('sales/quote_address');
$installer->run("
ALTER TABLE  $tablequote ADD  `workphone` varchar(255) NOT NULL
");
 
$tablequote = $this->getTable('sales/order_address');
$installer->run("
ALTER TABLE  $tablequote ADD  `workphone` varchar(255) NOT NULL
");

/*$installer->run("

DROP TABLE IF EXISTS '{$this->getTable('dokuoco/api_debug')}';
CREATE TABLE '{$this->getTable('dokuoco/api_debug')}' (
'nsia_id' int(11) NOT NULL auto_increment,
'start_time' datetime NOT NULL default '0000-00-00 00:00:00',
'finish_time' datetime NOT NULL default '0000-00-00 00:00:00',
'status' varchar(50) NOT NULL default '',
'statustype' char(1) NOT NULL default '',
'amount' double NOT NULL default '0',
'nsia_order_id' varchar(125) NOT NULL default '0',
'response_code' varchar(10) NOT NULL default '',
'approval_code' varchar(30) NOT NULL default '',
'result_message' varchar(20) NOT NULL default '',
'payment_channel' int(2) NOT NULL default '0',
'payment_code' varchar(10) NOT NULL default '',
'session_id' varchar(50) NOT NULL default '',
'bank' varchar(100) NOT NULL default '',
'mcn' varchar(50) NOT NULL default '',
'verify_id' varchar(50) NOT NULL default '',
'verify_score' int(3) NOT NULL default '0',
'verify_status' varchar(10) NOT NULL default '',
PRIMARY KEY ('nsia_id')
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=0;

    "); */
$installer->run("

DROP TABLE IF EXISTS dokuoco ;
CREATE TABLE dokuoco (
`nsia_id` int(11) NOT NULL auto_increment,
`start_time` datetime NOT NULL default '0000-00-00 00:00:00',
`finish_time` datetime NOT NULL default '0000-00-00 00:00:00',
`status` varchar(50) NOT NULL default '',
`statustype` char(1) NOT NULL default '',
`amount` double NOT NULL default '0',
`nsia_order_id` varchar(125) NOT NULL default '0',
`response_code` varchar(10) NOT NULL default '',
`approval_code` varchar(30) NOT NULL default '',
`result_message` varchar(20) NOT NULL default '',
`payment_channel` int(2) NOT NULL default '0',
`payment_code` varchar(10) NOT NULL default '',
`session_id` varchar(50) NOT NULL default '',
`bank` varchar(100) NOT NULL default '',
`mcn` varchar(50) NOT NULL default '',
`verify_id` varchar(50) NOT NULL default '',
`verify_score` int(3) NOT NULL default '0',
`verify_status` varchar(10) NOT NULL default '',
PRIMARY KEY (`nsia_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=0

  ");

//=========SQL method to insert new order status and state (declined)==============
/*
enable this block if new order status script above didnt work
*/
/*
$write = Mage::getSingleton('core/resource')->getConnection('core_write');
//insert new status into sales_order_status table
$write->query("INSERT INTO {$this->getTable('sales_order_status')} (status,label) VALUES ('dokudeclined','Declined') ;");

//insert new status into sales_order_status_state table
$write->query("INSERT INTO {$this->getTable('sales_order_status_state')} (status,state,is_default) VALUES ('dokudeclined','dokudeclined',1) ;");

//==================================================================================

//=========SQL method to insert new order status and state (Failed)==============
/*
enable this block if new order status script above didnt work


$write = Mage::getSingleton('core/resource')->getConnection('core_write');
//insert new status into sales_order_status table
$write->query("INSERT INTO {$this->getTable('sales_order_status')} (status,label) VALUES ('dokufailed','Failed') ;");

//insert new status into sales_order_status_state table
$write->query("INSERT INTO {$this->getTable('sales_order_status_state')} (status,state,is_default) VALUES ('dokufailed','dokufailed',1) ;");
*/
//==================================================================================

$installer->endSetup();









