<?php

class Mage_Dokuoco_Block_Standard_Response extends Mage_Core_Block_Abstract
{
    protected function _toHtml()
    {
    
    	Mage::log("got here");

    	$html = '<html><head><title>Transaction Status</title></head><body>';
          
			$result = $_GET['STATUSCODE'];
			$orderid = $_GET['TRANSIDMERCHANT'];
        
      //get the information from the module configuration
      $standard = Mage::getModel('Dokuoco/standard');

			$order = Mage::getModel('sales/order')->loadByIncrementId($orderid);
	
		
			//checks if a CMS page for success has been setup and uses that
			//otherwise uses a default message		
			$cms_pages = Mage::getModel('cms/page')->getCollection();
			$found = false;
			
			if ($result == "00") {
				$order->addStatusToHistory('Payment Successful',  $result , false);

				$order->setState(Mage_Sales_Model_Order::STATE_COMPLETE);
				$url = $standard->getSuccessUrl();
				foreach($cms_pages as $_page){
			     	$data = $_page->getData();
	    	       	if($data['identifier']=='success'){
	            		$html .= $data['content'];
	            		$found = true;
	    	       	}
			  }
	      if(!$found){
	          $html .= 'Thank you!<br/><br/>';
	      }
	      $html .= 'To continue browsing please <a href=' . $url . '><b><u>click here</u></b></a><br/><br/>';
			}else{
				$order->cancel()->save();
				$order->addStatusToHistory('Cancelled', $result , false);
				$url = $standard->getCancelUrl();
				foreach($cms_pages as $_page){
			    	$data = $_page->getData();
	    	       	if($data['identifier']=='error'){
	        	   		$html .= $data['content'];
	        	   		$found = true;
	    	       	}
			  }
	      if(!$found){
	           $html .= '<br/><br/>There was an error processing your order.<br/><br/>';
	      }
	      $html .= 'To try again please <a href=' . $url . '><b><u>click here</u></b></a><br /><br />';		
	    }

			$html .= '</body></html>';

			Mage::log($html);

    	return $html;
		}
}

?>