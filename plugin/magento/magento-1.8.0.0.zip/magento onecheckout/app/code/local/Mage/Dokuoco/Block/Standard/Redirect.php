<?php

class Mage_Dokuoco_Block_Standard_Redirect extends Mage_Core_Block_Abstract
{
    protected function _toHtml()
    {
        $standard = Mage::getModel('Dokuoco/standard');
        
        //Mage::getSingleton('core/session', array('name'=>'frontend'));
	$action = $standard->getConfigData('action');
	
        $form = new Varien_Data_Form();
        $form->setAction($action)
            ->setId('Dokuoco_standard_checkout')
            ->setName('Dokuoco_standard_checkout')
            ->setMethod('POST')
            ->setUseContainer(true);
	
	$currency = $standard->getQuote()->getBaseCurrencyCode();
	
        //$orderid = $standard->getCheckout()->getLastRealOrderId();
		//load system order id
		$orderid = $standard->getCheckout()->getLastOrderId();
		
		$amount = 0;
		
		if($standard->getConfigData('currency') == 'display'){
	        $currency = $standard->getQuote()->getStore()->getCurrentCurrency();
		$amount = $standard->getQuote()->getTotal();
		}else{
			$currency = $standard->getQuote()->getBaseCurrencyCode();
			$amount = $standard->getQuote()->getBaseGrandTotal();
		}
		//========get customer detail=======================
		
		 $customer = Mage::getSingleton('customer/session')->getCustomer();
		 $email = $customer->getEmail();// for email address
 		 $firstname = $customer->getFirstname();//  For first name
 		 $lastname= $customer->getLastname();// For last name
		 $fullname = $firstname." ".$lastname;
		 $quote = Mage::getSingleton('checkout/session')->getQuote();
		$billingAddress = $quote->getBillingAddress();
		$shippingAddress = $quote->getShippingAddress();
		$country = $billingAddress->getCountry();
		$city = $billingAddress->getCity();
		$state = $billingAddress->getRegion();
		$zipcode = $billingAddress->getPostcode();
		$telephone = $billingAddress->getTelephone();
		$mobilephone = $billingAddress->getMobilephone();
		$workphone = $billingAddress->getWorkphone();
		$dob = $customer->getDob();
		$birthday = date('Ymd', strtotime($dob));
		
		
		//==================================================
		
        $getTgl = Mage::getModel('core/date')->timestamp(time());
		$nowTgl = date('YmdHms', $getTgl);
		//echo date('m/d/y h:i:s', $now);
        $merchantid = $standard->getConfigData('merchantid');
        $mallid = $standard->getConfigData('mallid');
        $url = $standard->getConfigData('url');
        $chainnum = $standard->getConfigData('chainnum');
        $shared = $standard->getConfigData('shared');
        $password = $standard->getConfigData('password');
        $acquirerBIN = $standard->getConfigData('acquirerbin');
        $type = $standard->getConfigData('type');
        
	if ($type=="")
	{
        $type = "IMMEDIATE";
	}
	
	if ($chainnum=="")
	{
	$chainnum = "NA";
	}
	
	if ($acquirerBIN =="")
	{
	$acquirerBIN = "410504";
	}
	
	if ($password=="")
	{
        $password = "nsiapay";
	}
	
        $currency = "360";
	
	$session = Mage::getSingleton('checkout/session');
	$sesId = $session->getId();

				$basket = "";

				foreach ($session->getQuote()->getAllItems() as $item) {
				    
				    $basket .= $item->getName() . ",";
				    $basket .= number_format($item->getBaseCalculationPrice(),2,'.','') . ",";
				    $basket .= $item->getQty() . ",";
						$basket .= number_format($item->getRowTotal(),2,'.','') . ";";
				}
				
				$shipping=Mage::getSingleton('checkout/session');
				$basket.=$shipping->getQuote()->getShippingAddress()->getShippingDescription().",";
				$basket.= $shipping->getQuote()->getShippingAddress()->getShippingAmount().",1,".$shipping->getQuote()->getShippingAddress()->getShippingAmount();

		$connection = Mage::getSingleton('core/resource')->getConnection('core_write');
		
		$connection->query("insert into dokuoco (start_time,status,statustype,amount,nsia_order_id) values (now(),'Requested','R',".$amount.",'".$orderid."') ");
		
		
		$originalString = $amount;
		$Encrypter_variables= array(".0000");
		$Variables_replace = array(".00");
		$amount1= str_replace($Encrypter_variables, $Variables_replace, $originalString);
		$words = sha1($amount1.$mallid.$shared.$orderid);
		
        //$form->addField('MERCHANTID', 'hidden', array('name'=>'MERCHANTID', 'value'=>$merchantid));
		$form->addField('MALLID', 'hidden', array('name'=>'MALLID', 'value'=>$mallid));
		$form->addField('CHAINMERCHANT', 'hidden', array('name'=>'CHAINMERCHANT', 'value'=>$chainnum));
		$form->addField('AMOUNT', 'hidden', array('name'=>'AMOUNT', 'value'=>$amount1));
		$form->addField('PURCHASEAMOUNT', 'hidden', array('name'=>'PURCHASEAMOUNT', 'value'=>$amount1));
		$form->addField('TRANSIDMERCHANT', 'hidden', array('name'=>'TRANSIDMERCHANT', 'value'=>$orderid));
		$form->addField('WORDS', 'hidden', array('name'=>'WORDS', 'value'=>$words));
		$form->addField('REQUESTDATETIME', 'hidden', array('name'=>'REQUESTDATETIME', 'value'=>$nowTgl));
		$form->addField('CURRENCY', 'hidden', array('name'=>'CURRENCY', 'value'=>$currency));
		$form->addField('PURCHASECURRENCY', 'hidden', array('name'=>'PURCHASECURRENCY', 'value'=>$currency));
		$form->addField('SESSIONID', 'hidden', array('name'=>'SESSIONID', 'value'=>$words));
		$form->addField('NAME', 'hidden', array('name'=>'NAME', 'value'=>$fullname));
		$form->addField('EMAIL', 'hidden', array('name'=>'EMAIL', 'value'=>$email));
		$form->addField('ADDRESS', 'hidden', array('name'=>'ADDRESS', 'value'=>$orderid));
		$form->addField('CITY', 'hidden', array('name'=>'CITY', 'value'=>$city));
		$form->addField('STATE', 'hidden', array('name'=>'STATE', 'value'=>$state));
		$form->addField('COUNTRY', 'hidden', array('name'=>'COUNTRY', 'value'=>$country));
		$form->addField('ZIPCODE', 'hidden', array('name'=>'ZIPCODE', 'value'=>$orderid));
		$form->addField('HOMEPHONE', 'hidden', array('name'=>'HOMEPHONE', 'value'=>$telephone));
		$form->addField('MOBILEPHONE', 'hidden', array('MOBILEPHONE'=>'EMAIL', 'value'=>$mobilephone));
		$form->addField('WORKPHONE', 'hidden', array('name'=>'WORKPHONE', 'value'=>$workphone));
		$form->addField('BIRTHDATE', 'hidden', array('name'=>'BIRTHDATE', 'value'=>$birthday));
		$form->addField('BASKET', 'hidden', array('name'=>'BASKET', 'value'=>$basket));
		
		
        
        //$form->addField('URL', 'hidden', array('name'=>'URL', 'value'=>$url));
        
        
        //$form->addField('TYPE', 'hidden', array('name'=>'TYPE', 'value'=>$type));
        
        //$form->addField('acquirerBIN', 'hidden', array('name'=>'acquirerBIN', 'value'=>$acquirerBIN));
        
       // $form->addField('password', 'hidden', array('name'=>'password', 'value'=>$password));

        $html = '<html><body>';
        $html.= $this->__('You will be redirected to DOKU in a few seconds.');
        $html.= $form->toHtml();
        $html.= '<script type="text/javascript">document.getElementById("Dokuoco_standard_checkout").submit();</script>';
        $html.= '</body></html>';
        
	        Mage::log($html);

        return $html;
    }
}