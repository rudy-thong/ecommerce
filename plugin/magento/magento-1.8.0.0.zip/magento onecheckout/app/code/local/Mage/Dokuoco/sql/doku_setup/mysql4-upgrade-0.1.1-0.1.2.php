<?php

$installer = $this;


$installer->startSetup();
$statusTable        = $installer->getTable('sales/order_status');
$statusStateTable   = $installer->getTable('sales/order_status_state');
$statusLabelTable   = $installer->getTable('sales/order_status_label');

$data = array(
    array('status' => 'dokudeclined', 'label' => 'Declined')
);
$installer->getConnection()->insertArray($statusTable, array('status', 'label'), $data);

$data = array(
    array('status' => 'dokudeclined', 'state' => 'dokudeclined', 'is_default' => 1)
);
$installer->getConnection()->insertArray($statusStateTable, array('status', 'state', 'is_default'), $data);


$installer->run("


CREATE TABLE '{$this->getTable('dokuoco/api_debug')}' (
'nsia_id' int(11) NOT NULL auto_increment,
'start_time' datetime NOT NULL default '0000-00-00 00:00:00',
'finish_time' datetime NOT NULL default '0000-00-00 00:00:00',
'status' varchar(50) NOT NULL default '',
'amount' double NOT NULL default '0',
'nsia_order_id' varchar(125) NOT NULL default '0',
'session_id' varchar(50) NOT NULL default '',
PRIMARY KEY ('nsia_id')
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=0;

    ");

$installer->endSetup();




