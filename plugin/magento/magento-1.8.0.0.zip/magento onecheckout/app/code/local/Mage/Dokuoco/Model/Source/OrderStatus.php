<?php

class Mage_Dokuoco_Model_Source_OrderStatus{
	
    public function toOptionArray()
    {
        return array(
            array('value' => 'Pending DOKUOCO', 'label' => Mage::helper('Dokuoco')->__('Processing')),
        );
    }
}