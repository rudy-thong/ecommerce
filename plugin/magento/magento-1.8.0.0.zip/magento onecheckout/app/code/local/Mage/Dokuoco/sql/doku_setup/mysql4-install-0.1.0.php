<?php

$installer = $this;


$installer->startSetup();



$installer->run("


CREATE TABLE dokuoco (
`nsia_id` int(11) NOT NULL auto_increment,
`start_time` datetime NOT NULL default '0000-00-00 00:00:00',
`finish_time` datetime NOT NULL default '0000-00-00 00:00:00',
`status` varchar(50) NOT NULL default '',
`statustype` char(1) NOT NULL default '',
`amount` double NOT NULL default '0',
`nsia_order_id` varchar(125) NOT NULL default '0',
`response_code` varchar(10) NOT NULL default '',
`approval_code` varchar(30) NOT NULL default '',
`result_message` varchar(20) NOT NULL default '',
`payment_channel` int(2) NOT NULL default '0',
`payment_code` varchar(10) NOT NULL default '',
`session_id` varchar(50) NOT NULL default '',
`bank` varchar(100) NOT NULL default '',
`mcn` varchar(50) NOT NULL default '',
`verify_id` varchar(50) NOT NULL default '',
`verify_score` int(3) NOT NULL default '0',
`verify_status` varchar(10) NOT NULL default '',
PRIMARY KEY (`nsia_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=0

  ");


$installer->endSetup();












