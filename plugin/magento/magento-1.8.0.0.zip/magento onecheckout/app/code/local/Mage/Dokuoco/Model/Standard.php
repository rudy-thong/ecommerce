<?php

class Mage_Dokuoco_Model_Standard extends Mage_Payment_Model_Method_Abstract{
    //changing the payment to different from cc payment type and Doku payment type
    const PAYMENT_TYPE_AUTH = 'AUTHORIZATION';
    const PAYMENT_TYPE_SALE = 'SALE';

    protected $_code  = 'dokuoco';
    protected $_formBlockType = 'Dokuoco/standard_form';
    protected $_allowCurrencyCode = array('IDR');
	protected $paymentChanneld = null;


 	public function assignData($data)
    {
        if (!($data instanceof Varien_Object)) {
            $data = new Varien_Object($data);
        }
        $info = $this->getInfoInstance();
		
		$paymentChannel = $data->getDokuocoPayChannel();
		/*if (!$paymentChannel) {
            $paymentChannel = $data->getDokuocoPayChannel();
        }*/

       
		//echo "teslago=".$paymentChannel;
				
        $info->setCcType($data->getAmex());
		$this->setPaymentchannel($paymentChannel);
		
        return $this;
    }
	
	
	
	/*public function getPaymentChannel()
    {
        $info = $this->getInfoInstance();
        return $info->getDokuocoPayChannel();
    }*/
	public function setPaymentchannel($paymentChanneld)
    {
        $this->paymentchannel = $paymentChanneld;
    }
	public function getPaymentchannel()
    {
        return $this->paymentchannel;
    }
	

     /**
     * Get Doku session namespace
     *
     * @return Mage_Doku_Model_Session
     */
    public function getSession()
    {
        return Mage::getSingleton('Dokuoco/session');
    }
    

    /**
     * Get checkout session namespace
     *
     * @return Mage_Doku_Model_Session
     */
    public function getCheckout()
    {
        return Mage::getSingleton('checkout/session');
    }

    /**
     * Get current quote
     *
     * @return Mage_Sales_Model_Quote
     */
    public function getQuote()
    {
        return $this->getCheckout()->getQuote();
    }

    /**
     * Using internal pages for input payment data
     *
     * @return bool
     */
    public function canUseInternal()
    {
        return false;
    }

    /**
     * Using for multiple shipping address
     *
     * @return bool
     */
    public function canUseForMultishipping()
    {
        return false;
    }

    public function createFormBlock($name)
    {
        $block = $this->getLayout()->createBlock('Dokuoco/standard_form', $name)
            ->setMethod('Dokuoco_standard')
            ->setPayment($this->getPayment())
            ->setTemplate('Dokuoco/standard/form.phtml');

        return $block;
    }

    /*validate the currency code is avaialable to use for Doku or not*/
    public function validate()
    {
		//$quote = Mage::getSingleton('checkout/session')->getQuote();
		//$quote->setCustomerNoteNotify(true);

        parent::validate();
        $currency_code = $this->getQuote()->getBaseCurrencyCode();
		
        if (!in_array($currency_code,$this->_allowCurrencyCode)) {
            Mage::throwException(Mage::helper('Dokuoco')->__('Selected currency code ('.$currency_code.') is not compatabile with DOKUOCO'));
        }
        return $this;
    }

    public function onOrderValidate(Mage_Sales_Model_Order_Payment $payment)
    {
       return $this;
    }

    public function onInvoiceCreate(Mage_Sales_Model_Invoice_Payment $payment)
    {

    }	

    public function canCapture()
    {
        return true;
    }

    public function getOrderPlaceRedirectUrl()
    {
          return Mage::getUrl('Dokuoco/standard/redirect', array('_secure' => true));
    }

    public function getDokuocoUrl(){
 		//$url = "http://luna.nsiapay.com/ipg_payment/RegisterOrderInfo";
 		//$url = "https://www.nsiapay.com/ipg_payment/RegisterOrderInfo"; 
		$url = "http://localhost/tes.php";
		return $url;
    }
		
    
    public function getDebug()
    {
        return Mage::getStoreConfig('Dokuoco/wps/debug_flag');
    }

    public function isInitializeNeeded()
    {
        return true;
    }
	

    public function initialize($paymentAction, $stateObject)
    {
        $state = Mage_Sales_Model_Order::STATE_PENDING_PAYMENT;
        $stateObject->setState($state);
        //$stateObject->setStatus(Mage::getSingleton('sales/order_config')->getStateDefaultStatus($state));
        $stateObject->setIsNotified(false);
    }
}

?>
